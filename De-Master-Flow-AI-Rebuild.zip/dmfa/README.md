# De-Master Flow AI: full rebuild

## Folders
- `backend/` Node API (login, credits, Stability images, Runway videos, gallery, report, delete account)
- `www/index.html` the whole mobile app (no build step)
- `capacitor.config.json`, `package.json` for Android packaging

## 1. Run the backend
1. Install Node 18+.
2. `cd backend && npm install`
3. Copy `.env.example` to `.env` and fill in JWT_SECRET, STABILITY_API_KEY, RUNWAY_API_KEY, PUBLIC_URL.
4. `npm start`
5. Deploy it (Render, Railway or a VPS). Attach a persistent disk and set DATA_DIR to its mount path (for example /data), because users and files are saved there. Use HTTPS.

## 2. Connect the app
Open `www/index.html` and set `API_BASE` to your live backend URL.

## 3. Build the Android bundle
```
npm install
npx cap add android
npx cap sync android
npx cap open android
```
In Android Studio: Build > Generate Signed Bundle (.aab). Back up your keystore.

## 4. Before Play Store
- Set the target audience to 18+ and match Data safety to the privacy policy.
- Test signup, image, video, report and delete on a real phone.
- Add Google Play Billing before selling credits.
- Replace the JSON file storage with a real database as users grow.

## Run as a website (no computer needed)
The backend also serves the app at its own link (`backend/public/index.html`). Deploy the backend, open your Render link, and the app is online. Share the link, or use "Add to Home screen" in Chrome.

To publish on Google Play without a computer, use pwabuilder.com with your Render link to generate the Android package (.aab). Replace `icon-192.png` and `icon-512.png` in `backend/public/` with your real icon first.
