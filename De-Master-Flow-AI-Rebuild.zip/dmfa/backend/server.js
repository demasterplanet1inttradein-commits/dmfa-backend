require("dotenv").config();
const express = require("express");
const cors = require("cors");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

const { PORT = 3000, JWT_SECRET, STABILITY_API_KEY, RUNWAY_API_KEY, PUBLIC_URL = "", DATA_DIR = __dirname, SUPPORT_EMAIL = "support@demasterflow.ai" } = process.env;
if (!JWT_SECRET) throw new Error("Set JWT_SECRET in .env");

// ---- tiny JSON "database" (swap for Postgres/Mongo before real scale) ----
fs.mkdirSync(DATA_DIR, { recursive: true });
const DB_FILE = path.join(DATA_DIR, "data.json");
const UPLOADS = path.join(DATA_DIR, "uploads");
fs.mkdirSync(UPLOADS, { recursive: true });
const db = fs.existsSync(DB_FILE) ? JSON.parse(fs.readFileSync(DB_FILE, "utf8")) : { users: [], items: [], reports: [], jobs: {} };
const save = () => fs.writeFileSync(DB_FILE, JSON.stringify(db));

const COST = { image: 4, video5: 25, video10: 50 };
const FREE_CREDITS = 20;
const BLOCK = /\b(nude|naked|nsfw|porn\w*|erotic|undress\w*|deepfake|loli\w*|child (nude|sex\w*)|sexual\w*)\b/i;
const STYLES = {
  realistic: "realistic photography, natural lighting",
  "3d": "3D animation, Pixar-style render",
  cartoon: "colorful cartoon illustration",
  cinematic: "cinematic film still, dramatic lighting",
  fantasy: "magical fantasy art",
  advertising: "clean advertising photography",
  product: "studio product photography",
  children: "colorful children's animation, friendly characters, soft lighting",
};
const STAB_ASPECT = { "16:9": "16:9", "9:16": "9:16", "1:1": "1:1", "4:5": "4:5" };
const RUNWAY_RATIO = { "16:9": "1280:720", "9:16": "720:1280", "1:1": "960:960", "4:5": "832:1104" };
const CAMERA = { orbit: "slow 360 orbit around the subject", dolly: "slow dolly in", tracking: "smooth tracking shot", crane: "crane shot rising up", pan: "gentle horizontal pan", tilt: "gentle vertical tilt", zoom: "slow zoom in", static: "locked-off static camera" };

const app = express();
const origins = ["https://localhost", "capacitor://localhost", "http://localhost", "http://localhost:3000"];
app.use(cors({ origin: (o, cb) => cb(null, !o || origins.includes(o)) }));
app.use(express.json({ limit: "1mb" }));
app.use("/uploads", express.static(UPLOADS));
app.use(express.static(path.join(__dirname, "public")));

// ---- helpers ----
const baseUrl = (req) => PUBLIC_URL || `${req.protocol}://${req.get("host")}`;
const wrap = (fn) => (req, res) => fn(req, res).catch((e) => res.status(e.status || 500).json({ error: e.message || "Server error" }));
const fail = (status, message) => Object.assign(new Error(message), { status });
const safe = (u) => ({ email: u.email, credits: u.credits });

function auth(req, res, next) {
  try {
    const t = (req.headers.authorization || "").replace("Bearer ", "");
    const { id } = jwt.verify(t, JWT_SECRET);
    req.user = db.users.find((u) => u.id === id);
    if (!req.user) throw new Error();
    next();
  } catch {
    res.status(401).json({ error: "Please log in again." });
  }
}

function checkPrompt(p) {
  if (!p || !p.trim()) throw fail(400, "Please enter a prompt.");
  if (p.length > 1500) throw fail(400, "Prompt is too long.");
  if (BLOCK.test(p)) throw fail(400, "This prompt isn't allowed. Please keep content safe and family-friendly.");
}

async function stabilityImage({ prompt, aspect, negativePrompt }) {
  if (!STABILITY_API_KEY) throw fail(500, "Image service not configured.");
  const fd = new FormData();
  fd.append("prompt", prompt);
  fd.append("aspect_ratio", STAB_ASPECT[aspect] || "16:9");
  fd.append("output_format", "png");
  if (negativePrompt) fd.append("negative_prompt", negativePrompt);
  const r = await fetch("https://api.stability.ai/v2beta/stable-image/generate/core", {
    method: "POST",
    headers: { Authorization: `Bearer ${STABILITY_API_KEY}`, Accept: "application/json" },
    body: fd,
  });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw fail(502, (j.errors && j.errors.join(", ")) || j.name || "Image service error.");
  if (j.finish_reason === "CONTENT_FILTERED") throw fail(400, "That prompt was blocked by the safety filter.");
  return Buffer.from(j.image, "base64");
}

function saveFile(buf, ext) {
  const name = crypto.randomBytes(12).toString("hex") + "." + ext;
  fs.writeFileSync(path.join(UPLOADS, name), buf);
  return name;
}

const addItem = (req, user, type, file, prompt) => {
  const item = { id: crypto.randomUUID(), userId: user.id, type, file, url: `${baseUrl(req)}/uploads/${file}`, prompt: prompt.slice(0, 200), createdAt: Date.now() };
  db.items.push(item);
  return item;
};

// ---- auth ----
app.post("/api/auth/signup", wrap(async (req, res) => {
  const { email = "", password = "" } = req.body;
  if (!/^\S+@\S+\.\S+$/.test(email)) throw fail(400, "Enter a valid email.");
  if (password.length < 8) throw fail(400, "Password must be at least 8 characters.");
  if (db.users.some((u) => u.email === email.toLowerCase())) throw fail(409, "Email already registered.");
  const user = { id: crypto.randomUUID(), email: email.toLowerCase(), hash: await bcrypt.hash(password, 10), credits: FREE_CREDITS, createdAt: Date.now() };
  db.users.push(user);
  save();
  res.json({ token: jwt.sign({ id: user.id }, JWT_SECRET, { expiresIn: "30d" }), user: safe(user) });
}));

app.post("/api/auth/login", wrap(async (req, res) => {
  const { email = "", password = "" } = req.body;
  const user = db.users.find((u) => u.email === email.toLowerCase());
  if (!user || !(await bcrypt.compare(password, user.hash))) throw fail(401, "Wrong email or password.");
  res.json({ token: jwt.sign({ id: user.id }, JWT_SECRET, { expiresIn: "30d" }), user: safe(user) });
}));

app.get("/api/credits", auth, (req, res) => res.json({ credits: req.user.credits, email: req.user.email }));

// ---- image ----
app.post("/api/image/generate", auth, wrap(async (req, res) => {
  const { prompt, style = "cinematic", aspect = "16:9", negativePrompt } = req.body;
  checkPrompt(prompt);
  if (req.user.credits < COST.image) throw fail(402, "Not enough credits.");
  const full = `${prompt.trim()}, ${STYLES[style] || ""}`;
  const buf = await stabilityImage({ prompt: full, aspect, negativePrompt });
  req.user.credits -= COST.image;
  const item = addItem(req, req.user, "image", saveFile(buf, "png"), prompt);
  save();
  res.json({ imageUrl: item.url, id: item.id, creditsLeft: req.user.credits });
}));

// ---- video: Stability image -> Runway image_to_video ----
async function runVideo(job, user, req) {
  const upd = (p, s) => { job.progress = p; if (s) job.status = s; save(); };
  try {
    upd(5, "running");
    const full = `${job.prompt}, ${STYLES[job.style] || ""}`;
    const img = await stabilityImage({ prompt: full, aspect: job.aspect });
    upd(25);
    const motion = `${job.prompt}. Camera: ${CAMERA[job.camera] || CAMERA.static}.`.slice(0, 900);
    const start = await fetch("https://api.dev.runwayml.com/v1/image_to_video", {
      method: "POST",
      headers: { Authorization: `Bearer ${RUNWAY_API_KEY}`, "X-Runway-Version": "2024-11-06", "Content-Type": "application/json" },
      body: JSON.stringify({
        model: "gen4_turbo",
        promptImage: `data:image/png;base64,${img.toString("base64")}`,
        promptText: motion,
        ratio: RUNWAY_RATIO[job.aspect] || "1280:720",
        duration: job.duration === 10 ? 10 : 5,
      }),
    });
    const sj = await start.json().catch(() => ({}));
    if (!start.ok) throw new Error(sj.error || "Video service error.");
    const deadline = Date.now() + 10 * 60000;
    while (Date.now() < deadline) {
      await new Promise((r) => setTimeout(r, 4000));
      const t = await (await fetch(`https://api.dev.runwayml.com/v1/tasks/${sj.id}`, {
        headers: { Authorization: `Bearer ${RUNWAY_API_KEY}`, "X-Runway-Version": "2024-11-06" },
      })).json();
      if (typeof t.progress === "number") upd(Math.min(95, 25 + Math.round(t.progress * 70)));
      if (t.status === "SUCCEEDED") {
        const buf = Buffer.from(await (await fetch(t.output[0])).arrayBuffer());
        const item = addItem(req, user, "video", saveFile(buf, "mp4"), job.prompt);
        job.videoUrl = item.url;
        job.creditsLeft = user.credits;
        upd(100, "done");
        return;
      }
      if (t.status === "FAILED" || t.status === "CANCELLED") throw new Error(t.failure || "Video generation failed.");
    }
    throw new Error("Video took too long.");
  } catch (e) {
    user.credits += job.cost; // refund
    job.error = e.message;
    job.creditsLeft = user.credits;
    upd(job.progress, "failed");
  }
}

app.post("/api/video/generate", auth, wrap(async (req, res) => {
  if (!RUNWAY_API_KEY) throw fail(500, "Video service not configured.");
  const { prompt, duration = 5, aspect = "16:9", style = "children", camera = "static" } = req.body;
  checkPrompt(prompt);
  const dur = Number(duration) === 10 ? 10 : 5;
  const cost = dur === 10 ? COST.video10 : COST.video5;
  if (req.user.credits < cost) throw fail(402, "Not enough credits.");
  req.user.credits -= cost;
  const jobId = crypto.randomUUID();
  const job = { id: jobId, userId: req.user.id, status: "queued", progress: 0, cost, prompt: prompt.trim(), duration: dur, aspect, style, camera };
  db.jobs[jobId] = job;
  save();
  runVideo(job, req.user, req);
  res.json({ jobId });
}));

app.get("/api/video/status/:id", auth, (req, res) => {
  const j = db.jobs[req.params.id];
  if (!j || j.userId !== req.user.id) return res.status(404).json({ error: "Job not found." });
  res.json({ status: j.status, progress: j.progress, videoUrl: j.videoUrl, creditsLeft: j.creditsLeft ?? req.user.credits, error: j.error });
});

// ---- gallery, report, delete ----
app.get("/api/gallery", auth, (req, res) =>
  res.json({ items: db.items.filter((i) => i.userId === req.user.id).sort((a, b) => b.createdAt - a.createdAt).map(({ id, type, url, prompt, createdAt }) => ({ id, type, url, prompt, createdAt })) }));

app.post("/api/report", auth, (req, res) => {
  const { content = "", reason = "other" } = req.body;
  db.reports.push({ id: crypto.randomUUID(), userId: req.user.id, content: String(content).slice(0, 300), reason: String(reason).slice(0, 100), at: Date.now() });
  save();
  res.json({ ok: true });
});

app.delete("/api/account", auth, (req, res) => {
  db.items.filter((i) => i.userId === req.user.id).forEach((i) => fs.rmSync(path.join(UPLOADS, i.file), { force: true }));
  db.items = db.items.filter((i) => i.userId !== req.user.id);
  db.users = db.users.filter((u) => u.id !== req.user.id);
  for (const k of Object.keys(db.jobs)) if (db.jobs[k].userId === req.user.id) delete db.jobs[k];
  save();
  res.json({ ok: true });
});

// public page Google Play needs for account deletion
app.get("/delete-account", (_req, res) =>
  res.send(`<!doctype html><meta name=viewport content="width=device-width,initial-scale=1"><body style="font-family:sans-serif;max-width:600px;margin:40px auto;padding:0 16px"><h1>Delete your De-Master Flow AI account</h1><p>In the app: Settings &rarr; Delete Account.</p><p>Or email <a href="mailto:${SUPPORT_EMAIL}">${SUPPORT_EMAIL}</a> from your registered address with the subject "Delete my account". Your profile, prompts and generated files are deleted within 30 days.</p></body>`));

app.get("/health", (_req, res) => res.json({ ok: true, name: "De-Master Flow AI API" }));
app.listen(PORT, () => console.log("API running on port " + PORT));
